CREATE USER 'hualuomoli'@'%'; 
GRANT ALL ON hualuomoli.* to 'hualuomoli'@'%';
